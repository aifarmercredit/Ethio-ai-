# Ethio AI

Flutter + Supabase + Gemini app.

## Run
```bash
flutter pub get
flutter run
```

## Supabase
The app uses the Ethio-Ai Supabase project. Keep server secret/service-role keys out of the Flutter app.
