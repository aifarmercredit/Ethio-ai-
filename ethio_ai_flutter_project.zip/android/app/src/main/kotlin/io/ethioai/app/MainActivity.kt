package io.ethioai.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
