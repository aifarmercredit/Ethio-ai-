// ETHIO AI - corrected main.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

const supabaseUrl = 'https://sxrjpluqbphdurwzciaa.supabase.co';
const supabasePublishableKey =
    'sb_publishable_dVky8N2fYPTCkw1fQKgnSg_X6yEvbl2';
final supabase = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabasePublishableKey);
  runApp(const EthioAI());
}

class EthioAI extends StatelessWidget {
  const EthioAI({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'Ethio AI',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF07120D),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF16A34A), brightness: Brightness.dark),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFF102019),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ), home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: supabase.auth.onAuthStateChange,
    builder: (_, s) => (s.data?.session ?? supabase.auth.currentSession) == null ? const LoginPage() : const HomePage(),
  );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController(), pass=TextEditingController(); bool busy=false, hide=true;
  void msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));
  Future<void> login() async { if(email.text.trim().isEmpty||pass.text.isEmpty){msg('Email fi password guuti.');return;} setState(()=>busy=true); try{await supabase.auth.signInWithPassword(email:email.text.trim(),password:pass.text);}on AuthException catch(e){msg(e.message);}catch(_){msg('Login failed.');}finally{if(mounted)setState(()=>busy=false);} }
  Future<void> google() async { try{await supabase.auth.signInWithOAuth(OAuthProvider.google,redirectTo:'io.ethioai.app://login-callback/');}catch(_){msg('Google login failed.');} }
  @override void dispose(){email.dispose();pass.dispose();super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[const Logo(),const SizedBox(height:24),const Text('Welcome back',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('Log in to your Ethio AI account',style:TextStyle(color:Colors.white60)),const SizedBox(height:28),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:busy?null:google,icon:const Icon(Icons.g_mobiledata),label:const Text('Continue with Google'),)),const SizedBox(height:20),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(prefixIcon:Icon(Icons.email_outlined),labelText:'Email')),const SizedBox(height:14),TextField(controller:pass,obscureText:hide,decoration:InputDecoration(prefixIcon:const Icon(Icons.lock_outline),labelText:'Password',suffixIcon:IconButton(onPressed:()=>setState(()=>hide=!hide),icon:Icon(hide?Icons.visibility:Icons.visibility_off)))),const SizedBox(height:22),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:login,style:FilledButton.styleFrom(backgroundColor:const Color(0xFF16A34A),padding:const EdgeInsets.symmetric(vertical:16)),child:busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Text('Log in'))),TextButton(onPressed:busy?null:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const RegisterPage())),child:const Text("Don't have an account? Create one"))])))));
}

class RegisterPage extends StatefulWidget { const RegisterPage({super.key}); @override State<RegisterPage> createState()=>_RegisterPageState(); }
class _RegisterPageState extends State<RegisterPage>{
  final name=TextEditingController(),email=TextEditingController(),pass=TextEditingController(); bool busy=false;
  void msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));
  Future<void> register()async{if(name.text.trim().isEmpty||email.text.trim().isEmpty||pass.text.length<6){msg('Maqaa, email fi password (6+) guuti.');return;}setState(()=>busy=true);try{final r=await supabase.auth.signUp(email:email.text.trim(),password:pass.text,data:{'full_name':name.text.trim()});if(!mounted)return;if(r.session==null){msg('Account uumame. Email kee verify godhi.');Navigator.pop(context);}}on AuthException catch(e){msg(e.message);}catch(_){msg('Registration failed.');}finally{if(mounted)setState(()=>busy=false);}}
  @override void dispose(){name.dispose();email.dispose();pass.dispose();super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create Account')),body:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[const Logo(),const SizedBox(height:24),TextField(controller:name,decoration:const InputDecoration(prefixIcon:Icon(Icons.person),labelText:'Full name')),const SizedBox(height:14),TextField(controller:email,decoration:const InputDecoration(prefixIcon:Icon(Icons.email),labelText:'Email')),const SizedBox(height:14),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(prefixIcon:Icon(Icons.lock),labelText:'Password')),const SizedBox(height:22),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:register,style:FilledButton.styleFrom(backgroundColor:const Color(0xFF16A34A)),child:busy?const CircularProgressIndicator():const Text('Create Account')))])));
}

class HomePage extends StatefulWidget{const HomePage({super.key});@override State<HomePage>createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{int index=0;final chatKey=GlobalKey<ChatPageState>();@override Widget build(BuildContext c){final pages=[ChatPage(key:chatKey),const HistoryPage(),const ProfilePage(),const SettingsPage()];return Scaffold(body:pages[index],bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[NavigationDestination(icon:Icon(Icons.chat_bubble_outline),selectedIcon:Icon(Icons.chat_bubble),label:'Chat'),NavigationDestination(icon:Icon(Icons.history),label:'History'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Settings')]));}}

class ChatPage extends StatefulWidget{const ChatPage({super.key});@override State<ChatPage>createState()=>ChatPageState();}
class ChatPageState extends State<ChatPage>{final input=TextEditingController(),scroll=ScrollController();final picker=ImagePicker(),speech=stt.SpeechToText();final messages=<Map<String,String>>[];String? chatId;bool busy=false,listening=false;
  void msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));
  void bottom()=>WidgetsBinding.instance.addPostFrameCallback((_){if(scroll.hasClients)scroll.animateTo(scroll.position.maxScrollExtent,duration:const Duration(milliseconds:250),curve:Curves.easeOut);});
  void add(String role,String text){if(!mounted)return;setState(()=>messages.add({'role':role,'content':text}));bottom();}
  Future<void> newChat() async {
    if (mounted) {
      setState(() {
        messages.clear();
        chatId = null;
      });
    }
  }
  Future<void> send()async{final text=input.text.trim();if(text.isEmpty||busy)return;input.clear();add('user',text);setState(()=>busy=true);try{final r=await supabase.functions.invoke('gemini-chat',body:{'message':text,if(chatId!=null)'chat_id':chatId});final d=r.data;if(d is! Map)throw Exception('Invalid response');chatId=d['chat_id']?.toString()??chatId;final a=d['answer']?.toString()??'';if(a.isEmpty)throw Exception('Empty response');add('assistant',a);}on FunctionException catch(e){add('assistant','Rakkoo: ${e.reasonPhrase??'Gemini request failed.'}');}catch(_){add('assistant','Connection/Gemini error. Mee irra deebi\'i.');}finally{if(mounted)setState(()=>busy=false);}}
  Future<void> image() async {
    if (busy) return;
    final f = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
      maxWidth: 1600,
    );
    if (f == null) return;

    setState(() => busy = true);
    add('user', '🖼️ ${f.name}');

    try {
      final bytes = await f.readAsBytes();
      final base64Image = base64Encode(bytes);
      final mime = f.mimeType ?? 'image/jpeg';

      final r = await supabase.functions.invoke(
        'gemini-chat',
        body: {
          'message': 'Analyze this image and explain what you see clearly.',
          if (chatId != null) 'chat_id': chatId,
          'image_base64': base64Image,
          'image_mime_type': mime,
        },
      );

      final d = r.data;
      if (d is! Map) throw Exception('Invalid response');
      chatId = d['chat_id']?.toString() ?? chatId;
      final answer = d['answer']?.toString() ?? '';
      if (answer.isEmpty) throw Exception('Empty response');
      add('assistant', answer);
    } on FunctionException catch (e) {
      add(
        'assistant',
        'Image analysis failed: ${e.reasonPhrase ?? 'Gemini request failed.'}',
      );
    } catch (_) {
      add('assistant', 'Image analysis error. Mee irra deebi\'i.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  Future<void> voice()async{if(listening){await speech.stop();if(mounted)setState(()=>listening=false);return;}final ok=await speech.initialize(onStatus:(s){if(mounted&&(s=='done'||s=='notListening'))setState(()=>listening=false);});if(!ok){msg('Speech recognition hin argamne.');return;}setState(()=>listening=true);await speech.listen(localeId:'en_US',onResult:(r){if(mounted){input.text=r.recognizedWords;input.selection=TextSelection.collapsed(offset:input.text.length);}});}
  @override void dispose(){input.dispose();scroll.dispose();speech.stop();super.dispose();}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Ethio AI',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:busy?null:newChat,icon:const Icon(Icons.add))]),body:Column(children:[Expanded(child:messages.isEmpty?const Welcome():ListView.builder(controller:scroll,padding:const EdgeInsets.all(16),itemCount:messages.length,itemBuilder:(_,i)=>Bubble(text:messages[i]['content']!,user:messages[i]['role']=='user'))),if(busy)const Padding(padding:EdgeInsets.all(8),child:Row(children:[SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)),SizedBox(width:10),Text('Ethio AI is thinking...')])),SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(8,6,8,10),child:Row(crossAxisAlignment:CrossAxisAlignment.end,children:[IconButton(onPressed:busy?null:image,icon:const Icon(Icons.image_outlined)),Expanded(child:TextField(controller:input,minLines:1,maxLines:5,decoration:const InputDecoration(hintText:'Message Ethio AI...',contentPadding:EdgeInsets.symmetric(horizontal:16,vertical:14))),),IconButton(onPressed:busy?null:voice,icon:Icon(listening?Icons.mic:Icons.mic_none,color:listening?Colors.redAccent:null)),IconButton(onPressed:busy?null:send,icon:const Icon(Icons.send,color:Color(0xFF22C55E))) ])))]));
}

class Welcome extends StatelessWidget{const Welcome({super.key});@override Widget build(BuildContext c)=>const Center(child:Padding(padding:EdgeInsets.all(30),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Logo(),SizedBox(height:22),Text('Welcome to Ethio AI',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),SizedBox(height:10),Text('Ask anything in Afaan Oromoo, Amharic, or English.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white60))])));}
class Bubble extends StatelessWidget{final String text;final bool user;const Bubble({super.key,required this.text,required this.user});@override Widget build(BuildContext c)=>Align(alignment:user?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:BoxConstraints(maxWidth:500),margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:user?const Color(0xFF166534):const Color(0xFF102019),borderRadius:BorderRadius.circular(17)),child:SelectableText(text)));}

class HistoryPage extends StatefulWidget{const HistoryPage({super.key});@override State<HistoryPage>createState()=>_HistoryPageState();}
class _HistoryPageState extends State<HistoryPage>{bool loading=true;List<Map<String,dynamic>> chats=[];@override void initState(){super.initState();load();}Future<void>load()async{try{final u=supabase.auth.currentUser;if(u==null)return;final d=await supabase.from('chats').select().eq('user_id',u.id).order('updated_at',ascending:false);chats=List<Map<String,dynamic>>.from(d);}catch(_){msg('History load failed.');}finally{if(mounted)setState(()=>loading=false);}}void msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));Future<void>del(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete chat?'),
        content: const Text('This chat and its messages will be deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.from('chats').delete().eq('id', id);
      await load();
    } catch (_) {
      msg('Delete failed.');
    }
  }@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('💬 Chat History'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):chats.isEmpty?const Center(child:Text('No chat history yet.')):ListView.builder(itemCount:chats.length,itemBuilder:(_,i){final x=chats[i],id=x['id'].toString(),title=x['title']?.toString()??'New Chat';return ListTile(leading:const Icon(Icons.chat),title:Text(title),subtitle:Text(x['updated_at']?.toString()??''),trailing:IconButton(onPressed:()=>del(id),icon:const Icon(Icons.delete_outline)),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ChatDetailPage(id:id,title:title)));}));}
}
class ChatDetailPage extends StatefulWidget{final String id,title;const ChatDetailPage({super.key,required this.id,required this.title});@override State<ChatDetailPage>createState()=>_ChatDetailPageState();}
class _ChatDetailPageState extends State<ChatDetailPage>{bool loading=true;List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{try{final u=supabase.auth.currentUser;if(u==null)return;final d=await supabase.from('messages').select().eq('chat_id',widget.id).eq('user_id',u.id).order('created_at');rows=List<Map<String,dynamic>>.from(d);}catch(_){ }finally{if(mounted)setState(()=>loading=false);}}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.title)),body:loading?const Center(child:CircularProgressIndicator()):ListView.builder(padding:const EdgeInsets.all(16),itemCount:rows.length,itemBuilder:(_,i)=>Bubble(text:rows[i]['content']?.toString()??'',user:rows[i]['role']=='user')));}

class ProfilePage extends StatefulWidget{const ProfilePage({super.key});@override State<ProfilePage>createState()=>_ProfilePageState();}
class _ProfilePageState extends State<ProfilePage>{final name=TextEditingController(),phone=TextEditingController();Map<String,dynamic>? p;bool loading=true,saving=false;@override void initState(){super.initState();load();}Future<void>load()async{final u=supabase.auth.currentUser;if(u==null)return;try{p=await supabase.from('profiles').select().eq('id',u.id).maybeSingle();name.text=(p?['full_name']??u.userMetadata?['full_name']??'').toString();phone.text=(p?['phone']??'').toString();}catch(_){msg('Profile load failed.');}finally{if(mounted)setState(()=>loading=false);}}void msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));Future<void>save()async{final u=supabase.auth.currentUser;if(u==null)return;setState(()=>saving=true);try{final d={'id':u.id,'full_name':name.text.trim(),'phone':phone.text.trim(),'updated_at':DateTime.now().toIso8601String()};await supabase.from('profiles').upsert(d);p = {
        if (p != null) ...p!,
        ...d,
      };msg('Profile saved.');}catch(_){msg('Profile save failed.');}finally{if(mounted)setState(()=>saving=false);}}@override void dispose(){name.dispose();phone.dispose();super.dispose();}@override Widget build(BuildContext c){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));final plan=p?['plan']?.toString()??'free';return Scaffold(appBar:AppBar(title:const Text('👤 My Profile')),body:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[const CircleAvatar(radius:55,backgroundColor:Color(0xFF16A34A),child:Icon(Icons.person,size:60)),const SizedBox(height:24),TextField(controller:name,decoration:const InputDecoration(labelText:'Full name',prefixIcon:Icon(Icons.person))),const SizedBox(height:14),TextField(controller:phone,decoration:const InputDecoration(labelText:'Phone number',prefixIcon:Icon(Icons.phone))),const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton(onPressed:saving?null:save,style:FilledButton.styleFrom(backgroundColor:const Color(0xFF16A34A)),child:saving?const CircularProgressIndicator():const Text('Save Profile'))),const SizedBox(height:18),Card(child:ListTile(leading:Icon(plan=='pro'?Icons.workspace_premium:Icons.person,color:plan=='pro'?Colors.amber:null),title:Text(plan=='pro'?'💳 Ethio AI PRO ACTIVE':'FREE Account'),subtitle:Text(p?['pro_until']?.toString()??'Free plan'))),const SizedBox(height:18),OutlinedButton.icon(onPressed:()=>supabase.auth.signOut(),icon:const Icon(Icons.logout),label:const Text('Log out'))])));}}

class SettingsPage extends StatelessWidget{const SettingsPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('⚙️ Settings')),body:ListView(children:[ListTile(leading:const Icon(Icons.language),title:const Text('Language'),subtitle:const Text('Afaan Oromoo • Amharic • English'),onTap:()=>showDialog(context:c,builder:(_)=>SimpleDialog(title:const Text('Choose language'),children:[for(final x in ['English','Afaan Oromoo','Amharic / አማርኛ'])SimpleDialogOption(onPressed:()=>Navigator.pop(c),child:Text(x))]))),const Divider(),ListTile(leading:const Icon(Icons.security),title:const Text('Security'),subtitle:const Text('Supabase Authentication'),onTap:()=>showDialog(context:c,builder:(_)=>const AlertDialog(title:Text('Security'),content:Text('Use a strong password and never share secret API keys.')))),ListTile(leading:const Icon(Icons.info_outline),title:const Text('About Ethio AI'),onTap:()=>showAboutDialog(context:c,applicationName:'Ethio AI',applicationVersion:'1.0.0'))]));}}

class Logo extends StatelessWidget{const Logo({super.key});@override Widget build(BuildContext c)=>Container(width:95,height:95,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:const Color(0xFF16A34A),width:3)),child:const Center(child:Text('AI',style:TextStyle(fontSize:32,fontWeight:FontWeight.bold,color:Color(0xFF22C55E)))));}
